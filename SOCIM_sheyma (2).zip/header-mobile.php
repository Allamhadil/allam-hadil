<!-- HEADER MOBILE-->
<header class="header-mobile d-block d-lg-none">
    <div class="header-mobile__bar">
        <div class="container-fluid">
            <div class="header-mobile-inner">
                <a class="logo" href="index.php">
                    <img src="images/icon/logo.png" alt="CoolAdmin" />
                </a>
                <button class="hamburger hamburger--slider" type="button">
                            <span class="hamburger-box">
                                <span class="hamburger-inner"></span>
                            </span>
                </button>
            </div>
        </div>
    </div>
    <nav class="navbar-mobile">
        <div class="container-fluid">
            <ul class="navbar-mobile__list list-unstyled">
                <li class="active has-sub">
                    <a class="js-arrow" href="index.php">
                        <i class="fas fa-home"></i>Accueil</a>
                </li>
                <?php
                if($_SESSION['type'] == 2 || $_SESSION['type'] == 0)

                    echo'<li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-file-text"></i> Promesses</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">';

                ?>
                        <?php
                        if($_SESSION['type'] == 2)
                            echo'<li>
                                            <a href="new-promesse.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                            <i class="fas fa-plus"></i> Créer promesse</a>
                                        </li>';
                        ?>

                        <?php
                        if($_SESSION['type'] == 2)
                            echo'<li>
                                    <a href="promesses.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <i class="fas fa-list-alt"></i> Les promesses</a>
                                 </li>';
                        ?>

                        <?php
                        if($_SESSION['type'] == 2 || $_SESSION['type'] == 0)
                            echo'</ul>
                    </li>';

                        ?>

                <?php

                if($_SESSION['type'] == 2)
                    echo'<li>
                                    <a href="new-visite.php">
                                    <i class="fas fa-flash"></i>Visites</a>
                                 </li>';
                ?>
                <?php

                if($_SESSION['type'] == 1 || $_SESSION['type'] == 2)
                    echo'<li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-link"></i></i>Contart de vente</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list" >';

                if($_SESSION['type'] == 1)
                    echo '<li>
                                    <a href="new-contrat.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <i class="fas fa-plus"></i> Créer contart</a>
                                </li>';
                elseif($_SESSION['type'] == 2)
                    echo'<li>
                                    <a href="signe-contrat.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <i class="fas fa-check"></i> Signé contrat</a>
                                </li>';

                if($_SESSION['type'] == 1 || $_SESSION['type'] == 2)
                    echo'</ul>
                        </li>';

                ?>

                <?php

                if($_SESSION['type'] == 2)
                    echo'<li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-briefcase"></i>Gestion</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list">
                                <li>
                                    <a href="Gestion-clients.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <i class="fas fa-users"></i> La liste des clients</a>
                                </li>
                                <li>
                                    <a href="Gestion-avocats.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                    <i class="fas fa-legal"></i> La liste des avocats</a>
                                </li>
                                <li>
                                    <a href="Gestion-immublies.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <i class="fas fa-hospital-o"></i> L\'immeubles</a>
                                </li>
                                <li>
                                    <a href="Gestion-appartement.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                        <i class="fas fa-home"></i> L\'appartements</a>
                                </li>
                            </ul>
                        </li>';
                ?>
            </ul>
        </div>
    </nav>
</header>
<!-- END HEADER MOBILE-->