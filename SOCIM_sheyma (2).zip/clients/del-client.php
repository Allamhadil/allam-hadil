<?php

require "../conn.php";
$ID = $_POST['cl_id'];

$delete = "UPDATE client set visible=0 WHERE Personne_id=$ID";
$conn->query($delete);

$delete = "UPDATE personne set visible=0 WHERE id=$ID";
$conn->query($delete);

header('Location: ' . $_SERVER['HTTP_REFERER']);
