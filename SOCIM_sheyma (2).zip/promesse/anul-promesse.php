<?php

require "../conn.php";

$num = $_POST['ds_num'];
$cus = $conn->real_escape_string($_POST['ds_cus']);
$pr_id = $_POST['ds_pr_id'];

$insert = "INSERT INTO desistement(Num, `Date`, Causes, Promesse_id) VALUES($num,DATE(NOW()),'$cus',$pr_id)";
$conn->query($insert);

header('Location: ' . $_SERVER['HTTP_REFERER']);
