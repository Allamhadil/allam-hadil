<?php

require "../conn.php";
$ID = $_POST['immubID'];

$delete = "DELETE FROM immeubles WHERE ID=$ID";
$conn->query($delete);

header('Location: ' . $_SERVER['HTTP_REFERER']);
