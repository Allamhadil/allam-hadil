<?php

require "../conn.php";


$name = $_POST['imu-name'];
$addr= $_POST['imu-address'];
$ID = $_POST['imu-id'];

$edit = "UPDATE immeubles SET Name='$name',Address='$addr' WHERE id=$ID";
$conn->query($edit);

header('Location: ' . $_SERVER['HTTP_REFERER']);
