<?php

require "conn.php";

$res1 = true;
$res2 = true;
$res3 = true;


if (isset($_POST['log_client'])){

    $cni = $_POST["cni"];

    $select = "SELECT *,client.id as cl_id from client,personne where client.Personne_id=personne.id and client.CNI='$cni'";
    $result = $conn->query($select);

    if ($result->num_rows > 0){
        $row = $result->fetch_assoc();

        if (session_status() == PHP_SESSION_NONE) {
            session_start();
            $_SESSION['isLog']=true;
        }

        $_SESSION['type']= 0; /* Client */
        $_SESSION['cni']= $cni;
        $_SESSION['cl_id']= $row['cl_id'];
        $_SESSION['fullName']= $row['Fname'].' '.$row['Lname'];

        header('Location: '.'index.php');
    }
    else{
        $res1 = false;
    }


}
elseif (isset($_POST['log_avocat'])){


    $nAuto = $_POST["nAuto"];

    $select = "SELECT *,avocat.id as av_id from avocat,personne where avocat.Personne_id=personne.id and avocat.NumAutorisation='$nAuto'";
    $result = $conn->query($select);

    if ($result->num_rows > 0){
        $row = $result->fetch_assoc();

        if (session_status() == PHP_SESSION_NONE) {
            session_start();
            $_SESSION['isLog']=true;
        }

        $_SESSION['type']= 1; /* Avocat */
        $_SESSION['nAuto']= $nAuto;
        $_SESSION['av_id']= $row['av_id'];
        $_SESSION['fullName']= $row['Fname'].' '.$row['Lname'];

        header('Location: '.'index.php');
    }
    else{
        $res2 = false;
    }
}
elseif (isset($_POST['log_admin'])){

    $mdp = $_POST["mdp"];

    if ($mdp === "admin"){

        if (session_status() == PHP_SESSION_NONE) {
            session_start();
            $_SESSION['isLog']=true;
        }

        $_SESSION['type']= 2; /* Administrateur */
        $_SESSION['fullName']= 'Administrateur';
        header('Location: '.'index.php');
    }
    else{
        $res3 = false;
    }
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>SOCIM | Login</title>

    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
    <div class="page-wrapper">
        <div class="page-content--bge5">
            <div class="container">
                <div class="login-wrap">
                    <div class="login-content">
                        <div class="login-logo">
                            <a href="#">
                                <img src="images/icon/logo.png" alt="CoolAdmin">
                            </a>
                        </div>
                        <div class="card-body">
                            <div class="custom-tab">

                                <nav>
                                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                                        <!-- <a class="nav-item nav-link active show" id="custom-nav-home-tab" data-toggle="tab" href="#custom-nav-home" role="tab" aria-controls="custom-nav-home" aria-selected="true">Client</a> -->
                                        <a class="nav-item nav-link active show" id="custom-nav-contact-tab" data-toggle="tab" href="#custom-nav-contact" role="tab" aria-controls="custom-nav-contact" aria-selected="true">Adminstrateur</a>
                                        <a class="nav-item nav-link" id="custom-nav-profile-tab" data-toggle="tab" href="#custom-nav-profile" role="tab" aria-controls="custom-nav-profile" aria-selected="false">Avocat</a>
                                    </div>
                                </nav>
                                <div class="tab-content pl-3 pt-2 text-center" id="nav-tabContent">
                                    <!-- <div class="tab-pane fade active show" id="custom-nav-home" role="tabpanel" aria-labelledby="custom-nav-home-tab">
                                        <br>
                                        <form action="" method="post">
                                            <label for="cc-payment" class="control-label mb-1">Veuillez entrer votre N°CNI</label>
                                            <hr>
                                            <div class="input-group" style="margin-bottom: 15px">
                                                <input type="text" id="username2" name="cni" placeholder="N°CNI" class="form-control">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-user"></i>
                                                </div>
                                            </div>
                                            <?php
                                            /*if($res1 == false)
                                                echo   '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
                                                            Votre numéro de CNI n\'a pas été trouvé.
                                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                                <span aria-hidden="true">×</span>
                                                            </button>
                                                        </div>';*/
                                            ?>
                                            <hr>
                                            <button name="log_client" type="submit" class="btn btn-lg btn-primary btn-block">
                                                <i class="fa fa-lock fa-lg"></i>&nbsp;
                                                <span id="payment-button-amount">Login</span>
                                            </button>
                                        </form>
                                    </div> -->
                                    <div class="tab-pane fade active show" id="custom-nav-contact" role="tabpanel" aria-labelledby="custom-nav-contact-tab">
                                        <br>
                                        <form action="" method="post">
                                            <label for="cc-payment" class="control-label mb-1">Veuillez entrer votre mot de passe</label>
                                            <hr>
                                            <div class="input-group" style="margin-bottom: 15px">
                                                <input type="password" id="username2" name="mdp" placeholder="Mot de passe" class="form-control">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-user"></i>
                                                </div>
                                            </div>

                                            <?php
                                            if($res3 == false)
                                                echo   '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
                                                            Le mot de passe est incorrect.
                                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                                <span aria-hidden="true">×</span>
                                                            </button>
                                                        </div>';
                                            ?>
                                            <hr>
                                            <button name="log_admin" type="submit" class="btn btn-lg btn-warning btn-block">
                                                <i class="fa fa-lock fa-lg"></i>&nbsp;
                                                <span id="payment-button-amount">Login</span>
                                            </button>
                                        </form>
                                    </div>

                                    <div class="tab-pane fade" id="custom-nav-profile" role="tabpanel" aria-labelledby="custom-nav-profile-tab">
                                        <br>
                                        <form action="" method="post">
                                            <label for="cc-payment" class="control-label mb-1">Veuillez entrer votre N°Autorisation</label>
                                            <hr>
                                            <div class="input-group" style="margin-bottom: 15px">
                                                <input type="text" id="username2" name="nAuto" placeholder="N°Autorisation" class="form-control">
                                                <div class="input-group-addon">
                                                    <i class="fa fa-user"></i>
                                                </div>
                                            </div>

                                            <?php
                                            if($res2 == false)
                                                echo   '<div class="sufee-alert alert with-close alert-danger alert-dismissible fade show">
                                                            Votre numéro d\'Autorisation n\'a pas été trouvé.
                                                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                                                <span aria-hidden="true">×</span>
                                                            </button>
                                                        </div>';
                                            ?>
                                            <hr>
                                            <button name="log_avocat" type="submit" class="btn btn-lg btn-secondary btn-block">
                                                <i class="fa fa-lock fa-lg"></i>&nbsp;
                                                <span id="payment-button-amount">Login</span>
                                            </button>
                                        </form>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="js/main.js"></script>

</body>

</html>
<!-- end document-->