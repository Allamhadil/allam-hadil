
<?php
ini_set('display_errors', 0); // Turn off displaying errors

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if ($_SESSION['isLog'] != true) {
    header('Location: '.'login.php');
}


require "conn.php";
$res = true;
if (isset($_POST['AddPr'])){

    $pr_avc = $_POST["pr_avc"];
    $vs_id = $_POST["pr_vs_id"];
    $pr_ht = $_POST["pr_ht"];
    $pr_ttc= $_POST["pr_ttc"];

    $insert = "INSERT INTO promesse(PrixHT, PrixTTC, Avance, MontantPaye, Visite_id, Appartement_id, Client_id ,Personne_id)
  VALUE($pr_ht, $pr_ttc, $pr_avc, $pr_avc, $vs_id,
        (SELECT visite.Appartement_id FROM visite WHERE visite.id = $vs_id),
        (SELECT visite.Client_id FROM visite WHERE visite.id = $vs_id),
        (SELECT visite.Personne_id FROM visite WHERE visite.id = $vs_id)
  )";

    $res = $res && $conn->query($insert);
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>SOCIM | Promesses</title>
    <!-- icon Page-->
    <link rel="shortcut icon" href="images/icon/logo-title.png" type="image/png">
    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
<div class="page-wrapper">

    <?php require 'header-mobile.php'; ?>

    <?php require 'menu-sidebar.php'; ?>

    <!-- PAGE CONTAINER-->
    <div class="page-container">

        <?php require 'header-desktop.php'; ?>

        <!-- MAIN CONTENT-->
        <div class="main-content">
            <div class="section__content section__content--p30">
                <div class="container-fluid" style="padding: 0px">
                    <div class="row">
                        <div class="col-lg-12">
                            <!-- USER DATA-->
                            <div class="user-data m-b-30" style="padding-top: 0px">
                                <div class="card-header"><i class="fa fa-info-circle fa-lg"></i>&nbsp;&nbsp;Données de <strong>promesses</strong></div>
                                <div class="table-responsive table-data">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <td>Données</td>
                                            <td>Client</td>
                                            <td>Appartement</td>
                                            <td>état</td>
                                            <td>Contrat</td>
                                            <!-- <td>Action</td> -->
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        $select = "SELECT  concat(client.CNI,'.<br><i class=\"far fa-user\"></i> ',personne.Fname,' ',personne.Lname,'.<br><i class=\"fas fa-map-marker\"></i> ',personne.Address,'.<br><i class=\"fas fa-briefcase\"></i> ',client.Profession,'.<br><i class=\"fas fa-phone\"></i> ',personne.Tel) as client,
                                                            concat(immeubles.Name,' N°',appartement.num,'<br><i class=\"fas fa-map-marker\"></i> ',immeubles.Address,'.<br><i class=\"fas fa-external-link-alt\"></i> ',appartement.superficie,'m².<br><i class=\"fas fa-list-ol\"></i> ',appartement.NbrChmb,' Chambres.') as appartement,
                                                            concat('<i class=\"far fa-hand-point-right\"></i> N°Promesse: ',promesse.id,'<br><i class=\"fas fa-money-bill-alt\"></i> Prix HT: ',promesse.PrixHT,' DA.<br><i class=\"far fa-money-bill-alt\"></i> Prix TTC: ',promesse.PrixTTC,' DA.<br><i class=\"fab fa-autoprefixer\"></i> Avance: ',promesse.Avance,' DA.<br><i class=\"far fa-money-bill-alt\"></i> Montant paye: ',promesse.MontantPaye,' DA.') as promesse,
                                                            promesse.id,
                                                            promesse.MontantPaye as mp,
                                                            promesse.PrixTTC as ttc,
                                                            appartement.Remise as rem
                                                    FROM visite,client,appartement,promesse,personne,immeubles WHERE
                                                      visite.id=promesse.Visite_id AND
                                                      promesse.Personne_id=personne.id AND
                                                      promesse.Client_id=client.id AND
                                                    --   promesse.Client_id = ".$_SESSION['cl_id']." AND 
                                                      promesse.Appartement_id=appartement.id AND
                                                      immeubles.id = appartement.Immeubles_id";

                                        $result = $conn->query($select);

                                        if ($result->num_rows > 0) {
                                            while($row = $result->fetch_assoc()) {
                                                $client = $row["client"];
                                                $appr = $row["appartement"];
                                                $prms = $row["promesse"];
                                                $mp = $row["mp"];
                                                $ttc = $row["ttc"];
                                                $id = $row["id"];
                                                $rem = $row["rem"];

                                                $select2 = "SELECT count(*) AS cnt FROM desistement where desistement.Promesse_id=".$id;
                                                $result2 = $conn->query($select2);

                                                $select3 = "SELECT count(*) AS cnt FROM contrat where contrat.Promesse_id=".$id;
                                                $result3 = $conn->query($select3);

                                                $select4 = "SELECT contrat.Etat FROM contrat WHERE contrat.Promesse_id=".$id;
                                                $result4 = $conn->query($select4);
                                                // echo json_encode($id);
                                                $ds2='Style="Display:none"';
                                                $icon='<i class="fas fa-check fa-lg text-secondary" style="font-size: 30px;" data-toggle="tooltip" data-placement="top" title="" data-original-title="L\'appartement est été livrés à l\'acquérir."></i>';
                                                if($result2->fetch_assoc()['cnt'] > 0){
                                                    $statu ='<span class="role admin" >Annulé</span>';
                                                    $ds = 'Style="Display:none"';
                                                }
                                                else{
                                                    if($mp==$ttc){
                                                        $statu = '<span class="role member">terminé</span>';
                                                        if($rem==0){
                                                            $ds2 = '';
                                                            $icon = '';
                                                        }

                                                    }
                                                    else{
                                                        $statu = '<span class="role user">Attente</span>';
                                                        $icon = '';
                                                    }

                                                    if($result4->fetch_assoc()['etat'] == 0)
                                                        $ds = '';
                                                    else
                                                        $ds = 'Style="Display:none"';
                                                }

                                                if($result3->fetch_assoc()['cnt'] == 0)
                                                    $contrat ='<span class="role admin">Pas encore</span>';
                                                else
                                                    $contrat = '<button type="button" onclick="document.forms[\'con'.$row["id"].'\'].submit()" class="btn btn-outline-success btn-sm">Contrat</button>
                                                                <form action="contrat.php" id="con'.$row["id"].'" method="post"><input type="hidden" name="pr_id" value="'.$row["id"].'" ></form>';
                                                echo '<tr>
                                                        <td>
                                                            <div class="table-data__info">
                                                                <span>
                                                                    <a href="#"> '.$prms.'
                                                                    <br>
                                                                    <form action="paiement.php" method="post" id="del'.$row["id"].'">
                                                                        <input type="hidden" name="pr_id" value="'.$id.'">
                                                                    </form>
                                                                    <button type="button" class="btn btn-link btn-sm" onclick="document.forms[\'del'.$row["id"].'\'].submit()">
                                                                        <i class="fas fa-shopping-cart"></i>&nbsp; nouveau paiement</button>
                                                                    </a>
                                                                </span>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="table-data__info">
                                                                <span>
                                                                    <a href="#"><i class="far fa-id-card"></i> '.$client.'<br>
                                                                    </a>
                                                                </span>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <div class="table-data__info">
                                                                <span>
                                                                    <a href="#"><i class="fas fa-home"></i> '.$appr.'<br>
                                                                    </a>
                                                                </span>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            '.$statu. '
                                                        </td>
                                                        <td>
                                                            '.$contrat. '
                                                        </td>

                                                    </tr>';

                                                                                                            // <td> 
                                                        //     <div class="row"  style="max-width: 30px">
                                                        //                 <span class="more annul_promesse" '.$ds.'   data-toggle="modal" data-target="#mediumModal" data-id="'.$id.'"  data-toggle="tooltip" data-placement="top" title="" data-original-title="Annulation la promesse">
                                                        //                     <i class="fas fa-ban"></i>
                                                        //                 </span>
                                                        //                 <form action="appartements/rec-appart.php" id="rec'.$id.'" method="post">
                                                        //                     <span class="more annul_promesse" '.$ds2.' onclick="document.forms[\'rec'.$id.'\'].submit()" type="submit"  data-toggle="tooltip" data-placement="top" title="" data-original-title="Recevoire l\'appartement">
                                                        //                         <i class="far fa-check-circle"></i>
                                                        //                     </span>
                                                        //                     <input type="hidden" name="apr_id" value="'.$id.'" >
                                                        //                 </form>
                                                        //                 '.$icon.'
                                                        //     </div>
                                                        // </td>

                                            }
                                        }
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- END USER DATA-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<div class="modal fade" id="mediumModal" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="mediumModalLabel">Mettre à jour l'immeuble</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="promesse/anul-promesse.php" method="post">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="cc-name" class="control-label mb-1">N°Désistement</label>
                        <input name="ds_num"  type="text" class="form-control cc-name valid">
                    </div>
                    <div class="form-group">
                        <label for="cc-name" class="control-label mb-1">Causes de désistement</label>
                        <textarea name="ds_cus" rows="5" placeholder="Content..." class="form-control"></textarea>
                    </div>
                </div>
                <input type="hidden" id="ds_pr_id" name="ds_pr_id" value="">
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary">Confirmer</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Jquery JS-->
<script src="vendor/jquery-3.2.1.min.js"></script>

<script src="js/script.js"></script>

<!-- Bootstrap JS-->
<script src="vendor/bootstrap-4.1/popper.min.js"></script>
<script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
<!-- Vendor JS       -->
<script src="vendor/slick/slick.min.js">
</script>
<script src="vendor/wow/wow.min.js"></script>
<script src="vendor/animsition/animsition.min.js"></script>
<script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
</script>
<script src="vendor/counter-up/jquery.waypoints.min.js"></script>
<script src="vendor/counter-up/jquery.counterup.min.js">
</script>
<script src="vendor/circle-progress/circle-progress.min.js"></script>
<script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="vendor/chartjs/Chart.bundle.min.js"></script>
<script src="vendor/select2/select2.min.js">
</script>

<!-- Main JS-->
<script src="js/main.js"></script>

</body>

</html>
<!-- end document-->
