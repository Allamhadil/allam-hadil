<!-- HEADER DESKTOP-->
<header class="header-desktop">
    <div class="section__content section__content--p30">
        <div class="container-fluid">
            <div class="header-wrap">
                <form class="form-header" action="" method="POST">
                </form>
                <div class="header-button">
                    <div style="margin-right: 100px" class="account-wrap">
                        <div class="account-item clearfix js-item-menu">
                            <div class="content" style="font-size: 30px">
                                <span class="badge <?php

                                if($_SESSION['type']==2)
                                    echo "badge-warning Warning";
                                elseif($_SESSION['type']==1)
                                    echo "badge-secondary Secondary";
                                else
                                    echo "badge-primary Primary";


                                ?> Warning"><?php echo$_SESSION['fullName'] ?></span>
                            </div>
                        </div>
                    </div>

                    <form action="destroy.php" id="logout" method="post">
                        <div class="noti-wrap">
                            <div class="noti__item js-item-menu" onclick="document.forms['logout'].submit()">
                                <i class="zmdi zmdi-power-off"></i>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</header>
<!-- HEADER DESKTOP-->