
<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if ($_SESSION['isLog'] != true) {
    header('Location: '.'login.php');
}

require "conn.php";

$res = true;
if (isset($_POST['addVi'])){

    $client = $_POST["vs_cl"];
    $apprt = $_POST["vs_app"];
    $date = $_POST["vs_date"];
    $remrq = $conn->real_escape_string($_POST["vs_rem"]);
    $desc= $_POST["vs_des"];

    $insert = "INSERT INTO visite(Client_id, Appartement_id, Personne_id, `Date`, Remarques, Decision)
    VALUE($client, $apprt, (SELECT client.Personne_id from client WHERE client.id=$client),'$date', '$remrq', $desc)";

    $res = $conn->query($insert);
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>SOCIM | Créer visite</title>
    <!-- icon Page-->
    <link rel="shortcut icon" href="images/icon/logo-title.png" type="image/png">
    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
<div class="page-wrapper">

    <?php require 'header-mobile.php'; ?>

    <?php require 'menu-sidebar.php'; ?>

    <!-- PAGE CONTAINER-->
    <div class="page-container">

        <?php require 'header-desktop.php'; ?>

        <!-- MAIN CONTENT-->
        <div class="main-content">
            <div class="section__content section__content--p30">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-5">
                            <div class="card">
                                <div class="card-header"><i class="fa fa-user fa-lg"></i>&nbsp;&nbsp;Nouveau <strong>client</strong></div>
                                <div class="card-body">
                                    <form method="post">
                                        <div class="form-group">
                                            <label for="cc-name" class="control-label mb-1">Client</label>
                                            <div class="row form-group">
                                                <div class="col-12">
                                                    <select name="vs_cl" class="form-control">
                                                        <?php
                                                        $getClients = "Select client.id,CNI,Fname,Lname from client,personne WHERE client.Personne_id = personne.id";
                                                        $result = $conn->query($getClients);

                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $id = $row["id"];
                                                                $cni = $row["CNI"];
                                                                $fname = $row["Fname"];
                                                                $lname = $row["Lname"];
                                                                echo "<option value='$id'>$cni | $fname $lname</option>";
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="cc-name" class="control-label mb-1">Appartement</label>
                                            <div class="row form-group">
                                                <div class="col-12">
                                                    <select name="vs_app" class="form-control">
                                                        <?php
                                                        $getClients = "Select appartement.num,immeubles.Name,appartement.id from appartement,immeubles
WHERE appartement.id NOT IN (SELECT promesse.Appartement_id from promesse)
AND immeubles.id = appartement.Immeubles_id";
                                                        $result = $conn->query($getClients);

                                                        if ($result->num_rows > 0) {
                                                            while ($row = $result->fetch_assoc()) {
                                                                $id = $row["id"];
                                                                $num = $row["num"];
                                                                $name = $row["Name"];
                                                                echo "<option value='$id'>$name | N°$num</option>";
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="cc-name" class="control-label mb-1">Date</label>
                                            <input name="vs_date" type="date" class="form-control cc-name valid">
                                        </div>
                                        <div class="form-group">
                                            <label for="cc-name" class="control-label mb-1">Remarques</label>
                                            <textarea name="vs_rem" id="textarea-input" rows="3" placeholder="Contenue..." class="form-control"></textarea>
                                        </div>
                                        <div class="form-group">
                                            <label for="cc-name" class="control-label mb-1">Décision</label>
                                            <div class="row form-group">
                                                <div class="col-12">
                                                    <select name="vs_des" class="form-control">
                                                        <option value='0'>Refusé</option>
                                                        <option value='1'>Accepté</option>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <?php
                                        if (!$res){
                                            echo '<div class="alert alert-danger" role="alert">
											                Quelque chose ne va pas, vérifiez les données.
										                  </div>';
                                        }
                                        ?>
                                        <hr>
                                        <div>
                                            <button name="addVi" type="submit" class="btn btn-lg btn-info btn-block">
                                                <i class="fas fa-user-plus fa-lg"></i>
                                                <span id="payment-button-amount">Enregistrer</span>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-7">
                            <!-- VISITE DATA-->
                            <div class="user-data m-b-30" style="padding-top: 0px">
                                <div class="card-header"><i class="fa fa-info-circle fa-lg"></i>&nbsp;&nbsp;Données de <strong>clients</strong></div>
                                <div class="table-responsive table-data">
                                    <table class="table">
                                        <thead>
                                        <tr>
                                            <td>Données</td>
                                            <td>Statut</td>
                                            <td>Action</td>
                                            <td></td>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <?php
                                        $select = "SELECT visite.id,visite.Date,visite.Remarques,visite.Decision,personne.Fname,personne.Lname,client.CNI,appartement.num,immeubles.Name from appartement,client,personne,visite,immeubles WHERE visite.Personne_id=client.Personne_id and visite.Appartement_id=appartement.id and immeubles.id = appartement.Immeubles_id and personne.id=client.Personne_id";
                                        $result = $conn->query($select);

                                        if ($result->num_rows > 0) {
                                            while($row = $result->fetch_assoc()) {
                                                $id = $row["id"];
                                                $client = $row["CNI"].' | '.$row["Fname"]." ".$row["Lname"];
                                                $appart = $row["Name"].' | '.$row["num"];
                                                $date = $row["Date"];
                                                $desc = $row["Decision"];
                                                $rem = $row["Remarques"];
                                                if($desc == 0)
                                                    $statu ='<span class="role admin">Refusé</span>';
                                                else
                                                    $statu = '<span class="role user">Accepté</span>';
                                                echo '<tr>
                                                        <td>
                                                            <div class="table-data__info">
                                                                <h6 id="name'.$row["id"].'"><i class="far fa-calendar-alt"></i> '.$id.' • '.$date.'</h6>
                                                                <span>
                                                                    <a href="#"><i class="far fa-user"></i> '.$client.'<br>
                                                                    <i class="fas fa-home"></i> '.$appart. '</a>
                                                                </span>
                                                                   <hr>
                                                                   Remarques : <br>
                                                                <span style="font-size: 13px">'.$rem.'</span>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            '.$statu.'
                                                        </td>
                                                        <td>
                                                            <div class="row">
                                                                    <form method="post" action="visites/anul-promesse.php" id="del' .$id.'">
                                                                        <span class="more" onclick="document.forms[\'del'.$id.'\'].submit()">
                                                                            <i class="fa fa-trash-o"></i>
                                                                        </span>
                                                                        <input type="hidden" name="vs_id" value="'.$id.'"> 
                                                                    </form>
                                                            </div>
                                                        </td>
                                                    </tr>';

                                            }
                                        }
                                        ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <!-- END VISITE DATA-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- Jquery JS-->
<script src="vendor/jquery-3.2.1.min.js"></script>
<script src="js/script.js"></script>
<!-- Bootstrap JS-->
<script src="vendor/bootstrap-4.1/popper.min.js"></script>
<script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
<!-- Vendor JS       -->
<script src="vendor/slick/slick.min.js">
</script>
<script src="vendor/wow/wow.min.js"></script>
<script src="vendor/animsition/animsition.min.js"></script>
<script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
</script>
<script src="vendor/counter-up/jquery.waypoints.min.js"></script>
<script src="vendor/counter-up/jquery.counterup.min.js">
</script>
<script src="vendor/circle-progress/circle-progress.min.js"></script>
<script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="vendor/chartjs/Chart.bundle.min.js"></script>
<script src="vendor/select2/select2.min.js">
</script>

<!-- Main JS-->
<script src="js/main.js"></script>

</body>

</html>
<!-- end document-->
