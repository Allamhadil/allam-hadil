
<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if ($_SESSION['isLog'] != true) {
    header('Location: '.'login.php');
}



require "conn.php";
$res = true;
if (isset($_POST['addApp'])){


    $superficie = $_POST["app-superficie"];
    $nchambres = $_POST["app-ndchambres"];
    $prix = $_POST["app-prix"];
    $imeuble = $_POST["app-imeuble"];
    $num = $_POST["app-num"];

    $insert = "INSERT INTO appartement(num, superficie, NbrChmb, Prix, Remise, Immeubles_id) 
               VALUE($num, $superficie,$nchambres,$prix,0,$imeuble)";
    $res = $conn->query($insert);
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>SOCIM | Gestion appartements</title>
    <!-- icon Page-->
    <link rel="shortcut icon" href="images/icon/logo-title.png" type="image/png">
    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
    <div class="page-wrapper">

        <?php require 'header-mobile.php'; ?>

        <?php require 'menu-sidebar.php'; ?>

        <!-- PAGE CONTAINER-->
        <div class="page-container">

            <?php require 'header-desktop.php'; ?>

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-5">
                                <div class="card">
                                    <div class="card-header"><i class="fa fa-user fa-lg"></i>&nbsp;&nbsp;Nouveau <strong>Appartement</strong></div>
                                    <div class="card-body">
                                        <form method="post">
                                            <div class="form-group">
                                                <label for="cc-name" class="control-label mb-1">Superficie</label>
                                                <input id="cc-name" name="app-superficie" type="number" class="form-control cc-name valid">
                                            </div>
                                            <div class="form-group">
                                                <label for="cc-name" class="control-label mb-1">Nombre de chambres</label>
                                                <input id="cc-name" name="app-ndchambres" type="number" class="form-control cc-name valid">
                                            </div>
                                            <div class="form-group">
                                                <label for="cc-name" class="control-label mb-1">Prix</label>
                                                <input id="cc-name" name="app-prix" type="number" class="form-control cc-name valid">
                                            </div>
                                            <div class="form-group">
                                                <label for="cc-name" class="control-label mb-1">Dans l'immeuble</label>
                                                <div class="row form-group">
                                                    <div class="col-12">
                                                        <select name="app-imeuble" class="form-control">
                                                            <?php
                                                                $getImmeubles = "Select id,Name from immeubles";
                                                                $result = $conn->query($getImmeubles);

                                                                if ($result->num_rows > 0) {
                                                                    while ($row = $result->fetch_assoc()) {
                                                                        $id = $row["id"];
                                                                        $name = $row["Name"];
                                                                        echo "<option value='$id'>$name</option>";
                                                                    }
                                                                }
                                                            ?>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label for="cc-name" class="control-label mb-1">Numéro de chambre</label>
                                                <input id="cc-name" name="app-num" class="form-control cc-name valid">
                                            </div>
                                            <?php
                                                if (!$res){
                                                    echo '<div class="alert alert-danger" role="alert">
											                Quelque chose ne va pas, vérifiez les données.
										                  </div>';
                                                }
                                            ?>
                                            <hr>
                                            <div>
                                                <button name="addApp" type="submit" class="btn btn-lg btn-info btn-block">
                                                    <i class="fa fa-save fa-lg"></i>&nbsp;
                                                    <span id="payment-button-amount">Enregistrer</span>
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-7">
                                <!-- USER DATA-->
                                <div class="user-data m-b-30" style="padding-top: 0px">
                                    <div class="card-header"><i class="fa fa-info-circle fa-lg"></i>&nbsp;&nbsp;Données d'<strong>appartements</strong></div>

                                    <div class="table-responsive table-data">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <td>Données</td>
                                                    <td>State</td>
                                                    <td>Actions</td>
                                                    <td></td>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php
                                                $select = "Select immeubles.Name,appartement.* FROM immeubles,appartement WHERE Immeubles_id=immeubles.id";
                                                $result = $conn->query($select);

                                            if ($result->num_rows > 0) {
                                                while($row = $result->fetch_assoc()) {
                                                    $num = $row["num"];
                                                    $immeubleName = $row["Name"];
                                                    $nChambres = $row["NbrChmb"];
                                                    $superficie = $row["superficie"];
                                                    $prix = $row["Prix"];
                                                    $remise = $row["Remise"];
                                                    $id = $row["id"];

                                                    if($remise == 0){
                                                        $t='Disponible';
                                                        $r='member';
                                                    }
                                                    else{
                                                        $t='Vendu';
                                                        $r='admin';
                                                    }
                                                    echo '<tr>
                                                        <td>
                                                            <div class="table-data__info">
                                                                <h6 >N°<span id="num'.$id.'">'.$num.'</span> - <span id="prix'.$id.'">'.$prix.'</span> DA</h6>
                                                                <span>
                                                                    <a href="#" ><i class="far fa-copyright"></i> <span id="ndc'.$id.'">'.$nChambres.'</span> Chambres<br>
                                                                    <i class="far fa-square"></i> <span id="spr'.$id.'">'.$superficie.'</span>m²<br>
                                                                    <i class="fas fa-map-marker"></i> <span>'.$immeubleName.'</span></a>
                                                                </span>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <span class="role '.$r.'">'.$t.'</span>
                                                        </td>
                                                        <td>
                                                        
                                                            <div class="row">
                                                                <div class="col-6">
                                                                    <form method="post" action="appartements/del-appart.php" id="del'.$row["id"].'">
                                                                        <span class="more" onclick="document.forms[\'del'.$row["id"].'\'].submit()">
                                                                            <i class="fa fa-trash-o"></i>
                                                                        </span>
                                                                        <input type="hidden" name="appID" value="'.$row["id"].'"> 
                                                                    </form>
                                                                </div>
                                                                <div class="col-6">
                                                                    <form method="post" id="upd'.$row["id"].'">
                                                                        <span class="more editAppart" data-id="'.$id.'" data-toggle="modal" data-target="#mediumModal">
                                                                            <i class="fa fa-pencil"></i>
                                                                        </span>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </td>
                                                    </tr>';

                                                }
                                            }
                                            ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <!-- END USER DATA-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <div class="modal fade" id="mediumModal" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-md" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="mediumModalLabel">Mettre à jour l'immeuble</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">×</span>
                    </button>
                </div>
                <form action="appartements/edit-appart.php" method="post">
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="cc-name" class="control-label mb-1">Superficie</label>
                            <input id="ed-spr" name="app-spr" type="number" class="form-control cc-name valid">
                        </div>
                        <div class="form-group">
                            <label for="cc-name" class="control-label mb-1">Nombre de chambres</label>
                            <input id="ed-ndc" name="app-ndc" type="number" class="form-control cc-name valid">
                        </div>
                        <div class="form-group">
                            <label for="cc-name" class="control-label mb-1">Prix</label>
                            <input id="ed-prix" name="app-prix" type="number" class="form-control cc-name valid">
                        </div>
                        <div class="form-group">
                            <label for="cc-name" class="control-label mb-1">Dans l'immeuble</label>
                            <div class="row form-group">
                                <div class="col-12">
                                    <select name="app-imu" class="form-control">
                                        <?php
                                        $getImmeubles = "Select id,Name from immeubles";
                                        $result = $conn->query($getImmeubles);

                                        if ($result->num_rows > 0) {
                                            while ($row = $result->fetch_assoc()) {
                                                $id = $row["id"];
                                                $name = $row["Name"];
                                                echo "<option value='$id'>$name</option>";
                                            }
                                        }
                                        ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="cc-name" class="control-label mb-1">Numéro de chambre</label>
                            <input id="ed-num" name="app-num" class="form-control cc-name valid">
                        </div>
                    </div>
                    <input type="hidden" id="ed-id" name="app-id" value="">
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                        <button type="submit" class="btn btn-primary">Confirmer</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <script src="js/script.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="js/main.js"></script>

</body>

</html>
<!-- end document-->


