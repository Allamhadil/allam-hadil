<?php

require "../conn.php";
$ID = $_POST['vs_id'];

$delete = "DELETE FROM visite WHERE visite.id=$ID";
$conn->query($delete);

header('Location: ' . $_SERVER['HTTP_REFERER']);
