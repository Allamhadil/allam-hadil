
<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if ($_SESSION['isLog'] != true) {
    header('Location: '.'login.php');
}


require "conn.php";
$res = true;

if (isset($_POST['doPay'])){

    $montant = $_POST["pr_montant"];
    $mntpaye = $_POST["mn_pa"];
    $prittc = $_POST["pr_ttc"];

    $newVal = ((float)$prittc < (float)$mntpaye+(float)$montant)? $prittc : ((float)$montant+(float)$mntpaye);

    $update = "UPDATE promesse SET promesse.MontantPaye=".$newVal;
    $res = $res && $conn->query($update);
}

$p_id =  $_POST['pr_id'];

$res = 'SELECT promesse.PrixHT,promesse.PrixTTC,promesse.MontantPaye FROM promesse WHERE promesse.id='.$p_id;


$res = $conn->query($res);



if ($res->num_rows > 0){
    $row = $res->fetch_assoc();

    $ht = $row['PrixHT'];
    $ttc = $row['PrixTTC'];
    $mp = $row['MontantPaye'];

    $disable = ($ttc<=$mp)? "disabled":"";
}




?>



<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>SOCIM | Paiement</title>
    <!-- icon Page-->
    <link rel="shortcut icon" href="images/icon/logo-title.png" type="image/png">
    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
<div class="page-wrapper">

    <?php require 'header-mobile.php'; ?>

    <?php require 'menu-sidebar.php'; ?>

    <!-- PAGE CONTAINER-->
    <div class="page-container">

        <?php require 'header-desktop.php'; ?>

        <!-- MAIN CONTENT-->
        <div class="main-content">
            <div class="section__content section__content--p30">
                <div class="container-fluid" style="padding: 0px">
                    <div class="row">
                        <div class="col-lg-5">
                            <div class="card">
                                <div class="card-header"><i class="fas fa-file-alt"></i>&nbsp;&nbsp;Données de <strong>paiement</strong></div>
                                <div class="card-body">
                                    <form method="post">
                                        <div class="form-group">
                                            <div class="input-group">
                                                <input type="number" name="pr_montant" placeholder="Montant" class="form-control">
                                                <div class="input-group-addon">
                                                    <i>DA</i>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="cc-payment" class="control-label mb-1">Prix HT</label>
                                            <input name="pr_ht" id="pr_ht" readonly  type="text" value="<?php echo $ht; ?> DA" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="cc-name" class="control-label mb-1">Prix TTC</label>
                                            <input name="pr_ttc" id="pr_ttc"  readonly type="text" value="<?php echo $ttc; ?> DA" class="form-control cc-name valid">
                                        </div>
                                        <div class="form-group">
                                            <label for="cc-name" class="control-label mb-1">Montant paye</label>
                                            <input name="mn_pa" type="text" value="<?php echo $mp; ?> DA" readonly class="form-control cc-name valid">
                                        </div>
                                        <input type="hidden" name="pr_id" value="<?php echo $p_id; ?>">
                                        <?php
                                        if (!$res){
                                            echo '<div class="alert alert-danger" role="alert">
											                Quelque chose ne va pas, vérifiez les données.
										                  </div>';
                                        }
                                        ?>

                                        <hr>
                                        <div>
                                            <button <?php echo $disable; ?> name="doPay" type="submit" class="btn btn-lg btn-info btn-block">
                                                <i class="fas fa-shopping-cart fa-lg"></i>
                                                <span id="payment-button-amount">Enregistrer</span>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-7">
                            <div class="card">
                                <div class="card-header"><i class="fas fa-file-alt"></i>&nbsp;&nbsp;Données de <strong>paiement</strong></div>
                                <div class="card-body text-center">
                                    <h1>Requis</h1>
                                    <hr>
                                    <h1 style="font-size: 70px"><?php echo $ht-$mp; ?> DA</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<div class="modal fade" id="mediumModal" tabindex="-1" role="dialog" aria-labelledby="mediumModalLabel" style="display: none;" aria-hidden="true">
    <div class="modal-dialog modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="mediumModalLabel">Mettre à jour l'immeuble</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <form action="promesse/anul-promesse.php" method="post">
                <div class="modal-body">
                    <div class="form-group">
                        <label for="cc-name" class="control-label mb-1">N°Désistement</label>
                        <input name="ds_num"  type="text" class="form-control cc-name valid">
                    </div>
                    <div class="form-group">
                        <label for="cc-name" class="control-label mb-1">Causes de désistement</label>
                        <textarea name="ds_cus" rows="5" placeholder="Content..." class="form-control"></textarea>
                    </div>
                </div>
                <input type="hidden" id="ds_pr_id" name="ds_pr_id" value="">
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Annuler</button>
                    <button type="submit" class="btn btn-primary">Confirmer</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Jquery JS-->
<script src="vendor/jquery-3.2.1.min.js"></script>

<script src="js/script.js"></script>

<!-- Bootstrap JS-->
<script src="vendor/bootstrap-4.1/popper.min.js"></script>
<script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
<!-- Vendor JS       -->
<script src="vendor/slick/slick.min.js">
</script>
<script src="vendor/wow/wow.min.js"></script>
<script src="vendor/animsition/animsition.min.js"></script>
<script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
</script>
<script src="vendor/counter-up/jquery.waypoints.min.js"></script>
<script src="vendor/counter-up/jquery.counterup.min.js">
</script>
<script src="vendor/circle-progress/circle-progress.min.js"></script>
<script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="vendor/chartjs/Chart.bundle.min.js"></script>
<script src="vendor/select2/select2.min.js">
</script>

<!-- Main JS-->
<script src="js/main.js"></script>

</body>

</html>
<!-- end document-->
