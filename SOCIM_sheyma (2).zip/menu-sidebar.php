<!-- MENU SIDEBAR-->
<aside class="menu-sidebar d-none d-lg-block">
    <div class="logo">
        <a href="#">
            <img src="images/icon/logo.png" alt="Cool Admin" />
        </a>
    </div>
    <div class="menu-sidebar__content js-scrollbar1">
        <nav class="navbar-sidebar">
            <ul class="list-unstyled navbar__list">
                <li class="active has-sub">
                    <a class="js-arrow" href="index.php">
                        <i class="fas fa-home"></i>Accueil</a>
                </li>
                <?php
                if($_SESSION['type'] == 2 || $_SESSION['type'] == 0)

                    echo'<li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-file-text"></i> Promesses</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list"  style="display:block">';

                ?>
                        <?php
                        if($_SESSION['type'] == 2)
                            echo'<li>
                                            <a href="new-promesse.php">
                                            <i class="fas fa-plus"></i> Créer promesse</a>
                                        </li>';
                        ?>

                        <?php
                        if($_SESSION['type'] == 2)
                            echo'<li>
                                    <a href="promesses.php">
                                    <i class="fas fa-list-alt"></i> Les promesses</a>
                                 </li>';
                        ?>
                <?php
                if($_SESSION['type'] == 2 || $_SESSION['type'] == 0)
                    echo'</ul>
                    </li>';

                ?>
                <?php

                if($_SESSION['type'] == 2)
                    echo'<li>
                                    <a href="new-visite.php">
                                    <i class="fas fa-flash"></i>Visites</a>
                                 </li>';
                ?>
                <?php

                if($_SESSION['type'] == 1 || $_SESSION['type'] == 2)
                    echo'<li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-link"></i></i>Contart de vente</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list"  style="display:block">';

                if($_SESSION['type'] == 1)
                    echo '<li>
                                    <a href="new-contrat.php">
                                        <i class="fas fa-plus"></i>Créer contart</a>
                                </li>';
                elseif($_SESSION['type'] == 2)
                    echo'<li>
                                    <a href="signe-contrat.php">
                                        <i class="fas fa-check"></i>Signé contrat</a>
                                </li>';

                if($_SESSION['type'] == 1 || $_SESSION['type'] == 2)
                    echo'</ul>
                        </li>';

                ?>

                <?php

                if($_SESSION['type'] == 2)
                    echo'<li class="has-sub">
                            <a class="js-arrow" href="#">
                                <i class="fas fa-briefcase"></i>Gestion</a>
                            <ul class="list-unstyled navbar__sub-list js-sub-list" style="display:block">
                                <li>
                                    <a href="Gestion-clients.php"><i class="fas fa-users"></i>La liste des clients</a>
                                </li>
                                <li>
                                    <a href="Gestion-avocats.php"><i class="fas fa-legal"></i>La liste des avocats</a>
                                </li>
                                <li>
                                    <a href="Gestion-immublies.php">
                                        <i class="fas fa-hospital-o"></i>L\'immeubles</a>
                                </li>
                                <li>
                                    <a href="Gestion-appartement.php">
                                        <i class="fas fa-home"></i>L\'appartements</a>
                                </li>
                            </ul>
                        </li>';
                ?>
            </ul>
        </nav>
    </div>
</aside>
<!-- END MENU SIDEBAR-->