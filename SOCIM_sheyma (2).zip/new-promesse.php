
<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if ($_SESSION['isLog'] != true) {
    header('Location: '.'login.php');
}


require "conn.php";
$res = true;
if (isset($_POST['AddPr'])){

    $pr_avc = $_POST["pr_avc"];
    $vs_id = $_POST["pr_vs_id"];
    $pr_ht = $_POST["pr_ht"];
    $pr_ttc= $_POST["pr_ttc"];

    $insert = "INSERT INTO promesse(PrixHT, PrixTTC, Avance, MontantPaye, Visite_id, Appartement_id, Client_id ,Personne_id)
  VALUE($pr_ht, $pr_ttc, $pr_avc, $pr_avc, $vs_id,
        (SELECT visite.Appartement_id FROM visite WHERE visite.id = $vs_id),
        (SELECT visite.Client_id FROM visite WHERE visite.id = $vs_id),
        (SELECT visite.Personne_id FROM visite WHERE visite.id = $vs_id)
  )";

    $res = $res && $conn->query($insert);

}

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>SOCIM | Créer promesse</title>
    <!-- icon Page-->
    <link rel="shortcut icon" href="images/icon/logo-title.png" type="image/png">
    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
<div class="page-wrapper">

    <?php require 'header-mobile.php'; ?>

    <?php require 'menu-sidebar.php'; ?>

    <!-- PAGE CONTAINER-->
    <div class="page-container">

        <?php require 'header-desktop.php'; ?>

        <!-- MAIN CONTENT-->
        <div class="main-content">
            <div class="section__content section__content--p30">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="card">
                                <div class="card-header"><i class="fas fa-file-alt"></i>&nbsp;&nbsp;Nouveau <strong>promesse</strong></div>
                                <div class="card-body">
                                    <form method="post">
                                        <div class="form-group">
                                        <div class="input-group">
                                            <input type="number" id="pr_tva" placeholder="TVA" class="form-control">
                                            <div class="input-group-addon">
                                                <i>DA</i>
                                            </div>
                                        </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="cc-payment" class="control-label mb-1">Prix HT</label>
                                            <input name="pr_ht" id="pr_ht" readonly  type="text" value="0" class="form-control">
                                        </div>
                                        <div class="form-group">
                                            <label for="cc-name" class="control-label mb-1">Prix TTC</label>
                                            <input name="pr_ttc" id="pr_ttc"  readonly type="text" value="0" class="form-control cc-name valid">
                                        </div>
                                        <div class="form-group">
                                            <label for="cc-name" class="control-label mb-1">Avance</label>
                                            <input name="pr_avc" type="number" class="form-control cc-name valid">
                                        </div>
                                        <input type="hidden" id="pr_vs_id" name="pr_vs_id" value="">
                                        <hr>
                                        <div>
                                            <button name="AddPr" type="submit" class="btn btn-lg btn-info btn-block">
                                                <i class="fas fa-plus fa-lg"></i>
                                                <span id="payment-button-amount">Enregistrer</span>
                                            </button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <div class="col-lg-6">
                            <!-- PROMESSE DATA-->
                            <div class="card">
                                <div class="card-header"><i class="far fa-file-alt"></i>&nbsp;&nbsp;Promesse pour la <strong>visite</strong></div>
                                <div class="card-body">
                                    <form method="post">
                                        <div class="form-group">
                                            <label for="cc-name" class="control-label mb-1">Visite</label>
                                            <div class="row form-group">
                                                <div class="col-12">
                                                    <select name="vs_app" id="sel-visit" class="form-control">
                                                        <option>choisissez une visite</option>
                                                        <?php
                                                        $select = "SELECT visite.id,appartement.Prix,visite.Date,visite.Remarques,visite.Decision,personne.Fname,personne.Lname,client.CNI,appartement.num,immeubles.Name from appartement,client,personne,visite,immeubles WHERE visite.Personne_id=client.Personne_id and visite.Appartement_id=appartement.id and immeubles.id = appartement.Immeubles_id and personne.id=client.Personne_id and visite.id NOT IN (SELECT promesse.Visite_id from promesse)";
                                                        $result = $conn->query($select);

                                                        if ($result->num_rows > 0) {
                                                            while($row = $result->fetch_assoc()) {
                                                                $id = $row["id"];
                                                                $client = $row["CNI"].' | '.$row["Fname"]." ".$row["Lname"];
                                                                $appart = $row["Name"].' | '.$row["num"];
                                                                $date = $row["Date"];
                                                                $prix = $row["Prix"];

                                                                echo "<option id='visi$id' value='$id' data-prix='$prix' data-cl='$client' data-app='$appart' data-date='$date'>$id • $client avec $appart en $date</option>";
                                                            }
                                                        }
                                                        ?>
                                                    </select>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="form-group">
                                            <label for="cc-name" class="control-label mb-1">N° Visite</label>
                                            <input id="vs_num" type="name" disabled class="form-control cc-name valid">
                                        </div>
                                        <div class="form-group">
                                            <label for="cc-name" class="control-label mb-1">Client</label>
                                            <input id="vs_cl" type="name" disabled class="form-control cc-name valid">
                                        </div>
                                        <div class="form-group">
                                            <label for="cc-name" class="control-label mb-1">Appartement</label>
                                            <input id="vs_app" type="name" disabled class="form-control cc-name valid">
                                        </div>
                                        <div class="form-group">
                                            <label for="cc-name" class="control-label mb-1">Date</label>
                                            <input id="vs_date" type="name" disabled class="form-control cc-name valid">
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <!-- END PROMESSE DATA-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>

<!-- Jquery JS-->
<script src="vendor/jquery-3.2.1.min.js"></script>
<script src="js/script.js"></script>

<!-- Bootstrap JS-->
<script src="vendor/bootstrap-4.1/popper.min.js"></script>
<script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
<!-- Vendor JS       -->
<script src="vendor/slick/slick.min.js">
</script>
<script src="vendor/wow/wow.min.js"></script>
<script src="vendor/animsition/animsition.min.js"></script>
<script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
</script>
<script src="vendor/counter-up/jquery.waypoints.min.js"></script>
<script src="vendor/counter-up/jquery.counterup.min.js">
</script>
<script src="vendor/circle-progress/circle-progress.min.js"></script>
<script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
<script src="vendor/chartjs/Chart.bundle.min.js"></script>
<script src="vendor/select2/select2.min.js">
</script>

<!-- Main JS-->
<script src="js/main.js"></script>

</body>

</html>
<!-- end document-->
