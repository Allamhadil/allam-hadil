



$(".editImmeuble").on("click",function () {
    var name = $('#name'+$(this).attr("data-id")).text();
    var addr = $('#addr'+$(this).attr("data-id")).text();
    $('#ed-name').val(name);
    $('#ed-address').val(addr);
    $('#ed-id').val($(this).attr("data-id"));
});

$(".editAppart").on("click",function () {


    var num = $('#num'+$(this).attr("data-id")).text(),
        prix = $('#prix'+$(this).attr("data-id")).text(),
        ndc = $('#ndc'+$(this).attr("data-id")).text(),
        spr = $('#spr'+$(this).attr("data-id")).text();


    $('#ed-num').val(num);
    $('#ed-prix').val(prix);
    $('#ed-ndc').val(ndc);
    $('#ed-spr').val(spr);
    $('#ed-id').val($(this).attr("data-id"));
});

$(".btn-rem").on("click",function () {

    var rem = $(this).attr("data-rem").text();
    alert(rem);
});

$("#sel-visit").on('change', function() {

    var id = "#visi"+this.value;

    $("#pr_vs_id").val(+this.value);
    $("#vs_num").val(this.value);
    $("#vs_cl").val("N°CNI "+$(this).find(id).attr("data-cl"));
    $("#vs_app").val($(this).find(id).attr("data-app"));
    $("#vs_date").val($(this).find(id).attr("data-date"));

    $('#pr_ht').val($(this).find(id).attr("data-prix"));
});

$("#pr_tva").on('input',function () {
    var prixTTC = parseFloat($('#pr_ht').val())+parseFloat($('#pr_tva').val());
    $('#pr_ttc').val(prixTTC.toString());
});

$('.annul_promesse').on('click',function () {
    var id = $(this).attr("data-id");
    $('#ds_pr_id').val(id);
});
