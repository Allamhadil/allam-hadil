<?php

require "../conn.php";
$ID = $_POST['appID'];

$delete = "DELETE FROM appartement WHERE ID=$ID";
// echo $delete;
$conn->query($delete);

header('Location: ' . $_SERVER['HTTP_REFERER']);
