<?php

require "../conn.php";


$spr = $_POST['app-spr'];
$ndc = $_POST['app-ndc'];
$prix = $_POST['app-prix'];
$imu = $_POST['app-imu'];
$num = $_POST['app-num'];
$ID =  $_POST['app-id'];

$edit = "UPDATE appartement SET num='$num',superficie=$spr,NbrChmb=$ndc,Prix=$prix , Immeubles_id=$imu WHERE id=$ID";
$res = $conn->query($edit);


header('Location: ' . $_SERVER['HTTP_REFERER']);
