<?php



require "../conn.php";

$id =  $_POST['apr_id'];

$update = "UPDATE appartement SET appartement.Remise=1 WHERE appartement.id=(SELECT promesse.Appartement_id FROM promesse WHERE promesse.id=$id)";
$conn->query($update);

header('Location: ' . $_SERVER['HTTP_REFERER']);
