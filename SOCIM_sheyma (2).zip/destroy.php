<?php
/**
 * Created by PhpStorm.
 * User: Anouar
 * Date: 24/12/2018
 * Time: 13:19
 */

if (session_status() == PHP_SESSION_NONE) {
    session_start();
    $_SESSION['isLog']=false;

    header('Location: '.'login.php');
}

