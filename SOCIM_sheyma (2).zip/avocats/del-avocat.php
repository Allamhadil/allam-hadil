<?php

require "../conn.php";
$ID = $_POST['av_id'];

$delete = "DELETE FROM avocat WHERE avocat.Personne_id=$ID";
$conn->query($delete);

$delete = "DELETE FROM personne WHERE id=$ID";
$conn->query($delete);

header('Location: ' . $_SERVER['HTTP_REFERER']);
