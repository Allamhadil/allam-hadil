
<?php

if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

if ($_SESSION['isLog'] != true) {
    header('Location: '.'login.php');
}


require "conn.php";
$res = true;
if (isset($_POST['addCl'])){


    $cni = $_POST["cl_cni"];
    $fname = $_POST["cl_fname"];
    $lname = $_POST["cl_lname"];
    $addr = $_POST["cl_addr"];
    $ndt = $_POST["cl_ndt"];
    $prfs = $_POST["cl_prfs"];

    $insert = "INSERT INTO personne(Fname, Lname, Address, Tel) VALUE('$fname', '$lname', '$addr', '$ndt')";
    $res = $res && $conn->query($insert);

    $last_id = $conn->insert_id;

    $insert = "INSERT INTO client(CNI, Profession ,Personne_id) VALUE('$cni', '$prfs', $last_id)";

    $res = $res && $conn->query($insert);
}

?>



<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags-->
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="au theme template">
    <meta name="author" content="Hau Nguyen">
    <meta name="keywords" content="au theme template">

    <!-- Title Page-->
    <title>SOCIM | Gestion clients</title>
    <!-- icon Page-->
    <link rel="shortcut icon" href="images/icon/logo-title.png" type="image/png">
    <!-- Fontfaces CSS-->
    <link href="css/font-face.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-5/css/fontawesome-all.min.css" rel="stylesheet" media="all">
    <link href="vendor/font-awesome-4.7/css/font-awesome.min.css" rel="stylesheet" media="all">
    <link href="vendor/mdi-font/css/material-design-iconic-font.min.css" rel="stylesheet" media="all">

    <!-- Bootstrap CSS-->
    <link href="vendor/bootstrap-4.1/bootstrap.min.css" rel="stylesheet" media="all">

    <!-- Vendor CSS-->
    <link href="vendor/animsition/animsition.min.css" rel="stylesheet" media="all">
    <link href="vendor/bootstrap-progressbar/bootstrap-progressbar-3.3.4.min.css" rel="stylesheet" media="all">
    <link href="vendor/wow/animate.css" rel="stylesheet" media="all">
    <link href="vendor/css-hamburgers/hamburgers.min.css" rel="stylesheet" media="all">
    <link href="vendor/slick/slick.css" rel="stylesheet" media="all">
    <link href="vendor/select2/select2.min.css" rel="stylesheet" media="all">
    <link href="vendor/perfect-scrollbar/perfect-scrollbar.css" rel="stylesheet" media="all">

    <!-- Main CSS-->
    <link href="css/theme.css" rel="stylesheet" media="all">

</head>

<body class="animsition">
    <div class="page-wrapper">

        <?php require 'header-mobile.php'; ?>

        <?php require 'menu-sidebar.php'; ?>

        <!-- PAGE CONTAINER-->
        <div class="page-container">

            <?php require 'header-desktop.php'; ?>

            <!-- MAIN CONTENT-->
            <div class="main-content">
                <div class="section__content section__content--p30">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-lg-5">
                                <div class="card">
                                    <div class="card-header"><i class="fa fa-user fa-lg"></i>&nbsp;&nbsp;Nouveau <strong>client</strong></div>
                                    <div class="card-body">
                                        <form method="post">
                                            <div class="form-group">
                                                <label for="cc-payment" class="control-label mb-1">N° CNI</label>
                                                <input name="cl_cni" type="text" class="form-control">
                                            </div>
                                            <div class="form-group">
                                                <label for="cc-name" class="control-label mb-1">Nom</label>
                                                <input name="cl_fname" type="name" class="form-control cc-name valid">
                                            </div>
                                            <div class="form-group">
                                                <label for="cc-name" class="control-label mb-1">Prénome</label>
                                                <input name="cl_lname" type="name" class="form-control cc-name valid">
                                            </div>
                                            <div class="form-group">
                                                <label for="cc-name" class="control-label mb-1">Adresse</label>
                                                <input name="cl_addr" type="name" class="form-control cc-name valid">
                                            </div>
                                            <div class="form-group">
                                                <label for="cc-name" class="control-label mb-1">Numéro de téléphone</label>
                                                <input name="cl_ndt" type="name" class="form-control cc-name valid">
                                            </div>
                                            <div class="form-group">
                                                <label for="cc-name" class="control-label mb-1">Profession</label>
                                                <input name="cl_prfs" type="name" class="form-control cc-name valid">
                                            </div>
                                            <hr>
                                            <div>
                                                <button name="addCl" type="submit" class="btn btn-lg btn-info btn-block">
                                                    <i class="fas fa-user-plus fa-lg"></i>
                                                    <span id="payment-button-amount">Enregistrer</span>
                                                </button>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-7">
                                <!-- USER DATA-->
                                <div class="user-data m-b-30" style="padding-top: 0px">
                                    <div class="card-header"><i class="fa fa-info-circle fa-lg"></i>&nbsp;&nbsp;Données de <strong>clients</strong></div>
                                    <div class="table-responsive table-data">
                                        <table class="table">
                                            <thead>
                                                <tr>
                                                    <td>Données</td>
                                                    <td>Statut</td>
                                                    <td>Action</td>
                                                    <td></td>
                                                </tr>
                                            </thead>
                                            <tbody>
                                            <?php
                                            $select = "Select *,client.id,
                                                        (SELECT count(*) FROM promesse WHERE promesse.Client_id=personne.id AND
                                                        promesse.id in (SELECT contrat.Promesse_id from contrat WHERE contrat.Etat=0)) as etat
                                                        FROM client,personne WHERE personne.id=client.Personne_id AND client.visible=1";

                                            $result = $conn->query($select);

                                            if ($result->num_rows > 0) {
                                                while($row = $result->fetch_assoc()) {
                                                    $fname = $row["Fname"];
                                                    $lname = $row["Lname"];
                                                    $addr = $row["Address"];
                                                    $prfs = $row["Profession"];
                                                    $cni = $row["CNI"];
                                                    $id = $row["Personne_id"];
                                                    $etat = $row["etat"];

                                                    if($etat == 1){
                                                        $etat = 'Active';
                                                        $cl = 'member';
                                                    }
                                                    else{
                                                        $etat = 'Inacive';
                                                        $cl = 'admin';
                                                    }

                                                    echo '<tr>
                                                        <td>
                                                            <div class="table-data__info">
                                                                <h6 id="name'.$row["id"].'"><i class="far fa-user"></i> '.$fname.' '.$lname.'</h6>
                                                                <span>
                                                                    <a href="#"><i class="far fa-id-card"></i> '.$cni.'<br><i class="fas fa-map-marker"></i> '.$addr.'<br><i class="fas fa-briefcase"></i> '.$prfs. '</a>
                                                                </span>
                                                            </div>
                                                        </td>
                                                        <td>
                                                            <span class="role '.$cl.'">'.$etat.'</span>
                                                        </td>
                                                        <td>
                                                            <div class="row">
                                                                    <form method="post" action="/clients/del-client.php" id="del' .$id.'">
                                                                        <span class="more" onclick="document.forms[\'del'.$id.'\'].submit()">
                                                                            <i class="fa fa-trash-o"></i>
                                                                        </span>
                                                                        <input type="hidden" name="cl_id" value="'.$id.'"> 
                                                                    </form>
                                                            </div>
                                                        </td>
                                                    </tr>';

                                                }
                                            }
                                            ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <!-- END USER DATA-->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

    </div>

    <!-- Jquery JS-->
    <script src="vendor/jquery-3.2.1.min.js"></script>
    <!-- Bootstrap JS-->
    <script src="vendor/bootstrap-4.1/popper.min.js"></script>
    <script src="vendor/bootstrap-4.1/bootstrap.min.js"></script>
    <!-- Vendor JS       -->
    <script src="vendor/slick/slick.min.js">
    </script>
    <script src="vendor/wow/wow.min.js"></script>
    <script src="vendor/animsition/animsition.min.js"></script>
    <script src="vendor/bootstrap-progressbar/bootstrap-progressbar.min.js">
    </script>
    <script src="vendor/counter-up/jquery.waypoints.min.js"></script>
    <script src="vendor/counter-up/jquery.counterup.min.js">
    </script>
    <script src="vendor/circle-progress/circle-progress.min.js"></script>
    <script src="vendor/perfect-scrollbar/perfect-scrollbar.js"></script>
    <script src="vendor/chartjs/Chart.bundle.min.js"></script>
    <script src="vendor/select2/select2.min.js">
    </script>

    <!-- Main JS-->
    <script src="js/main.js"></script>

</body>

</html>
<!-- end document-->
